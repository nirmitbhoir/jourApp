package net.engdigest.jourApp.Service;

import net.engdigest.jourApp.Entity.User;
import net.engdigest.jourApp.Repository.UserRepository;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    private static final PasswordEncoder passwordencoder = new BCryptPasswordEncoder();

    // ✅ Use ONLY for new user registration
    public void saveNewUser(User user) {
        user.setPassword(passwordencoder.encode(user.getPassword()));
        user.setRoles(Arrays.asList("USER"));
        userRepository.save(user);
    }

    // ✅ Use for updating existing user credentials — encodes password but preserves roles
    public void saveUpdatedUser(User user) {
        user.setPassword(passwordencoder.encode(user.getPassword()));
        userRepository.save(user);
    }

    // ✅ Use for saving user without touching password (e.g. updating journal entry list)
    public void saveUser(User user) {
        userRepository.save(user);
    }

    public List<User> get() {
        return userRepository.findAll();
    }

    public Optional<User> findById(ObjectId id) {
        return userRepository.findById(id);
    }

    public void deleteById(ObjectId id) {
        userRepository.deleteById(id);
    }

    public User findByUserName(String username) {
        return userRepository.findByUserName(username);
    }
}